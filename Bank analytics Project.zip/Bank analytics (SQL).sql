select * from finance_1_sql;
select * from  finance_2_sql;

##### KPI 1 (YEAR WISE LOAN AMOUNT STATS) #####
select  year(issue_d) as y_year, sum(loan_amnt) as Total_Loan_amnt from finance_1_sql
group by y_year
order by  y_year;


##### KPI 2 (GRADE AND SUB GRADE WISE REVOL_BAL) #####
select f1.grade, f1.sub_grade,sum(f2.revol_bal) as total_revol_bal
from finance_1_sql f1 inner join finance_2_sql f2 
on(f1.id = f2.id) 
group by f1.grade,f1.sub_grade
order by f1.grade;

## KPI 2 GRADE WISE REVOL_BAL IN MILLIONS) ##
SELECT f1.grade, CONCAT(CAST(SUM(f2.revol_bal) / 1000000 AS DECIMAL(10, 2)), ' millions') AS sum_revol_bal_in_millions
FROM finance_1_sql AS f1 LEFT JOIN finance_2_sql AS f2 ON f1.id = f2.id
GROUP BY f1.grade
ORDER BY f1.grade;


##### KPI 3 (Total Payment for Verified Status Vs Total Payment for Non Verified Status) #####
select verification_status, round(sum(total_pymnt),2) as Total_payment
from finance_1_sql f1 inner join finance_2_sql f2 
on(f1.id = f2.id) 
where verification_status in('Verified', 'Not Verified')
group by verification_status;


##### KPI 4 (State wise and last_credit_pull_d wise loan status) #####
SELECT f1.addr_state,f1.loan_status,count(f2.last_credit_pull_d)AS Total_count
FROM finance_1_sql f1
LEFT JOIN finance_2_sql f2
ON f1.id=f2.id
GROUP BY 1,2
ORDER BY 1,2;


##### KPI 5 (Home ownership Vs last payment date stats) #####
SELECT f1.home_ownership,count(last_pymnt_d) AS count_last_pymnt_d
FROM finance_1_sql f1
LEFT JOIN finance_2_sql f2
ON f1.id=f2.id
GROUP BY 1
order by count(last_pymnt_d) desc;
